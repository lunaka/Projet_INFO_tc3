# -*- coding: utf-8 -*-
"""
Created on Fri Jun 15 14:00:08 2018

@author: Lenovo
"""

from raytracer import *
from numpy import *
from random import *
import sqlite3

def Pyramide_solid(scene,x0,y0,z0,taille):
    Sommet = vec3(x0,z0+taille,y0)
    vertices = [vec3(x0-taille/sqrt(2),z0,y0-taille/sqrt(2)), vec3(x0+taille/sqrt(2),z0,y0-taille/sqrt(2)), vec3(x0+taille/sqrt(2),z0,y0+taille/sqrt(2)), vec3(x0-taille/sqrt(2),z0,y0+taille/sqrt(2))]
    base = Polygon2(vertices, 1, diffuse=rgb(0.5,0.5,0))
    
    scene.append(Pyramid(base, Sommet, diffuse=rgb(random(),random(),random()), mirror=0, specular=0))    


def Sphere_solid(scene,x0,y0,z0,taille):
    scene.append(Sphere(vec3(x0,y0,z0),taille/2,diffuse=rgb(0.9,0.5,0.1), mirror=0, specular=0))
    

def Cylindre_solid(scene,x0,y0,z0,taille):
    scene.append(Cylinder(vec3(x0,y0,z0), vec3(0,1,0),taille/4,taille/2, mirror=0.25, specular=0.6, phong=140))

def Arbre(scene,x0,y0,z0,taille):
    V = vec3(0,1,0) # axe sur lequel il sera projété
    r = taille/6
    h = 4*r
    P = vec3(x0,y0,z0)
    
    scene.append(Cylinder(P, V, r, h, diffuse=rgb(0.9,0.5,0.1), mirror=0, specular=0))
    
    center = P + vec3(0,h,0) # Coordonnées entre -1 et 1 (x = horizontal, y = verticale, z = sens de la page)
    radius = 2*r
    scene.append(Sphere(center, radius, diffuse=rgb(0.1,0.9,0.1), mirror=0, specular=0))
    
def Sapin(scene,x0,y0,z0,taille):
    scene.append(Cylinder(vec3(x0,y0,z0), vec3(0,1,0),taille/3,1.3*taille, mirror=0.25, specular=0.6, phong=140))
    scene.append(ConeTrunk(vec3(x0,y0+3*taille,z0),vec3(0,-1,0), 2.5*taille, 2*taille, rgb(0.1,0.8,0.3)))

def Maison(scene,x0,y0,z0,taille):
    
    U = vec3(1,0,0)
    V = vec3(0,1,0) # axe sur lequel il sera projété
    C = vec3(x0+0,y0+0,z0+0)
    l = 0.3
    
    scene.append(Cube(C, U, V, l, diffuse=rgb(0.65,0.27,0.25), mirror=0, specular=0))
    S = vec3(0+x0,y0+0.5,z0+0.5) # Coordonnées entre -1 et 1 (x = horizontal, y = verticale, z = sens de la page)
    vertices = [vec3(x0-0.2,y0+0.2,z0-0.2), vec3(x0+0.2,y0+0.2,z0-0.2), vec3(x0+0.2,y0+0.2,z0+0.2), vec3(x0-0.2,y0+0.2,z0+0.2)]
    base = Polygon2(vertices, 1, diffuse=rgb(0.5,0.5,0), mirror=0, specular=0)
    
    scene.append(Pyramid(base, S, diffuse=rgb(0.9,0.5,0.1), mirror=0, specular=0))
#    
def Voiture(scene,x0,y0,z0,taille):
    P = [vec3(-0.3+x0,0.1+y0,-0.2+z0), vec3(0.3+x0,0.1+y0,-0.2+z0), vec3(x0-0.3,y0+0.1,z0+0.2), vec3(x0+0.3,y0+0.1,z0+0.2)]
    V = vec3(0,0,1) # axe sur lequel il sera projété
    r = 0.1
    h1 = 0.1
    h2 = -0.1

    scene.append(Cylinder(P[0], V, r, h2, diffuse=rgb(0.1,0.1,0.1), mirror=0, specular=0))
    scene.append(Cylinder(P[1], V, r, h2, diffuse=rgb(0.1,0.1,0.1), mirror=0, specular=0))
    scene.append(Cylinder(P[2], V, r, h1, diffuse=rgb(0.1,0.1,0.1), mirror=0, specular=0))
    scene.append(Cylinder(P[3], V, r, h1, diffuse=rgb(0.1,0.1,0.1), mirror=0, specular=0))

    U = vec3(1,0,0)
    V = vec3(0,0,1) # axe sur lequel il sera projété
    C1 = vec3(x0+0,y0+0.3,z0+0)
    l1 = 0.4

    C2 = vec3(0.3+x0,y0+0.2,z0-0.1)
    l2 = 0.2
    C3 = vec3(x0+0.3,y0+0.2,z0+0.1)
    C4 = vec3(x0-0.3,y0+0.2,z0+0.1)
    C5 = vec3(x0-0.3,y0+0.2,z0-0.1)
    
    scene.append(Cube(C1, U, V, l1, diffuse=rgb(0.9,0.1,0.1), mirror=0, specular=0))
    scene.append(Cube(C2, U, V, l2, diffuse=rgb(0.9,0.1,0.1), mirror=0, specular=0))
    scene.append(Cube(C3, U, V, l2, diffuse=rgb(0.9,0.1,0.1), mirror=0, specular=0))
    scene.append(Cube(C4, U, V, l2, diffuse=rgb(0.9,0.1,0.1), mirror=0, specular=0))
    scene.append(Cube(C5, U, V, l2, diffuse=rgb(0.9,0.1,0.1), mirror=0, specular=0))

def creer_scene(liste):
    #,serial): #liste=[ [pyramide,x0,y0,z0,taille], [sphere,x0,y0,z0,taille], ....]
    name=str(randint(0,10000))
    scene = Scene(name, 0, 1)
    
    scene.append(LightSource(vec3(-1., 2, -3), 1))
    scene.append(LightSource(vec3(0,0,0), rgb(0.94,1,0.94)))
    scene.append(LightSource(vec3(-30, 10, 0), rgb(0.6,0.2,1)))
    scene.append(LightSource(vec3(0., 40, 0), rgb(0.6,0.13,0)))
    scene.append(Plane(vec3(0,-0.4,0), vec3(0,1,0)))
    for k in (liste):
        if k[0]=='Pyramide':
            Pyramide_solid(scene,k[1],k[2],k[3],k[4])
        
        if k[0]=='Sphere':
            Sphere_solid(scene,k[1],k[2],k[3],k[4])
        
        if k[0]=='Cylindre':
            Cylindre_solid(scene,k[1],k[2],k[3],k[4])
        
        if k[0]=='Arbre':
            Arbre(scene,k[1],k[2],k[3],k[4])
            
        if k[0]=='Sapin':
            Sapin(scene,k[1],k[2],k[3],k[4])
        
        if k[0]=='Maison':
            Maison(scene,k[1],k[2],k[3],k[4])
        
        if k[0]=='Voiture':
            Voiture(scene,k[1],k[2],k[3],k[4])
    
    scene.initialize(E = vec3(0, 2, -10)).trace().save_image()
    #scene.serialize()
    
    

    conn= sqlite3.connect('raytracing.sqlite')
    c=conn.cursor()
    w=400
    h=300
    data=['scene '+name,str(liste),w, h, scene.ptime, scene.name]
    c.execute("INSERT INTO scene VALUES (NULL,?,?,?,?,?,?)",data)
    
    conn.commit()
    return (name)